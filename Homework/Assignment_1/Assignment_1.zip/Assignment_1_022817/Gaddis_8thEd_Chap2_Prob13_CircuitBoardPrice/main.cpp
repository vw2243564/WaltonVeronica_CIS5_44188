/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 9:23 PM
  Purpose: Programming challenge 13, Circuit Board Price
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float basePri=14.95;//base price of circuit board
    float perProf=0.35;//percent profit
    float cbPri;//circuit board price
    
    //Input values
    
    //Process by mapping inputs to outputs
    cbPri=(basePri*perProf)+basePri;
    
    //Output values
    cout<<"An electronics company that makes a 35% profit will make $"<<cbPri<<
            " on a circuit board that costs them $"<<basePri<<endl;

    //Exit stage right!
    return 0;
}