/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 8:56 PM
  Purpose: Programming challenge 6, Annual Pay
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short payAmt=2200;//amount earned each pay period
    unsigned short payPrd=26;//number of times paid in a year
    unsigned short yrPay;//total annual pay
    
    //Input values
    
    //Process by mapping inputs to outputs
    yrPay=payAmt*payPrd;
    
    //Output values
    cout<<"Employee's total annual pay is $"<<yrPay<<endl;

    //Exit stage right!
    return 0;
}