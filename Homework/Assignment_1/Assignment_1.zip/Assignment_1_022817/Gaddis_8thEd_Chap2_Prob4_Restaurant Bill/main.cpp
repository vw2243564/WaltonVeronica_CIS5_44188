/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 8:30 PM
  Purpose: Programming challenge 4, Restaurant Bill
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float bill=88.67;//restaurant meal bill
    float billTAX=0.0675;//tax of meal
    float billTip=0.20;//tip for total meal after tax
    float mealTAX;//meal + tax
    float total;//meal + tax + tip
    
    //Input values
    
    //Process by mapping inputs to outputs
    mealTAX=(bill*billTAX)+bill;
    total=(mealTAX*billTip)+mealTAX;
    
    //Output values
    cout<<"Cost of the meal is $"<<bill<<endl;
    cout<<"Tax amount is "<<billTAX<<endl;
    cout<<"Tip amount is "<<billTip<<endl;
    cout<<"The total bill amount is $"<<total<<endl;

    //Exit stage right!
    return 0;
}