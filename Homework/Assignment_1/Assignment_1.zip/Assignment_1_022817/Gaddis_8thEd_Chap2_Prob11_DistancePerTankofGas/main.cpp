/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 9:12 PM
  Purpose: Programming challenge 11, Distance per Tank of Gas
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short totGal=20;//full tank of gas
    float galTown=23.5;//miles per gallon in town
    float galHigh=28.9;//miles per gallon on highway
    float totTown, totHigh;//total miles on full tank of gas in town/on highway
    
    //Input values
    
    //Process by mapping inputs to outputs
    totTown=totGal*galTown;
    totHigh=totGal*galHigh;
    
    //Output values
    cout<<"A car with a full 20 gallon tank can go "<<totTown<<" miles, averaging "
            <<galTown<<" miles per hour in town."<<endl;
    cout<<"A car with a full 20 gallon tank can go "<<totHigh<<" miles, averaging "
            <<galHigh<<" miles per hour on the highway."<<endl;

    //Exit stage right!
    return 0;
}