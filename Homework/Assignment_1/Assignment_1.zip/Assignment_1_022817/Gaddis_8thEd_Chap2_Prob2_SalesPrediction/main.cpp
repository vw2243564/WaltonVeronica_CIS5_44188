/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 8:15 PM
  Purpose: Programming challenge 2, Sales Prediction
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned int yrSales=8600000;//8.6 million in sales this year
    float perTot=0.58f;//percent of total sales
    unsigned int total;//total amount the division will make this year
    
    //Input values
    
    //Process by mapping inputs to outputs
    total=yrSales*perTot;
    
    //Output values
    cout<<"The East Coast sales division will make "<<total<<" this year."<<endl;

    //Exit stage right!
    return 0;
}