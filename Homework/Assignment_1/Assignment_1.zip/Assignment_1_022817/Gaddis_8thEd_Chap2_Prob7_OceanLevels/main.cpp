/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 9:03 PM
  Purpose: Programming challenge 7, Ocean Levels
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float oLevel=1.5;//rising ocean levels per year in millimeters
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    
    //Output values
    cout<<"The ocean's water level rises "<<oLevel<<" millimeters per year."<<endl;
    cout<<"In 5 years the ocean's level will be "<<oLevel*5.0<<" millimeters higher."<<endl;
    cout<<"In 7 years the ocean's level will be "<<oLevel*7.0<<" millimeters higher."<<endl;
    cout<<"In 10 years the ocean's level will be "<<oLevel*10.0<<" millimeters higher."<<endl;

    //Exit stage right!
    return 0;
}