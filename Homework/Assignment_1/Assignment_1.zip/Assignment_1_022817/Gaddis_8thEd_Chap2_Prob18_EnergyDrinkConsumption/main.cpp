/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 9:33 PM
  Purpose: Programming challenge 18, Energy Drink Consumption
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short pplSrvy=16500;//customers surveyed
    float pplEne=0.15;//surveyed customers that purchased energy drinks
    float pplCEne=0.58;//surveyed customers that purchased energy drinks that prefer citrus flavored
    unsigned short totEne, totCEne;//number of people who purchased energy drinks/number who prefer citrus
    
    //Input values
    
    //Process by mapping inputs to outputs
    totEne=pplSrvy*pplEne;
    totCEne=totEne*pplCEne;
    
    //Output values
    cout<<"Of the "<<pplSrvy<<" surveyed, "<<totEne<<" bought one or more energy drinks per week."<<endl;
    cout<<"Of the "<<totEne<<" surveyed, "<<totCEne<<" prefer citrus flavors."<<endl;

    //Exit stage right!
    return 0;
}