/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 8:15 PM
  Purpose: Programming challenge 3, Sales Tax
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short itemP=95;//purchase
    float stTAX=0.04;//state sales tax
    float ctTAX=0.02;//county sales tax
    float totTAX;//total sales tax
    
    //Input values
    
    //Process by mapping inputs to outputs
    totTAX=(itemP*stTAX)+(itemP*ctTAX);
    
    //Output values
    cout<<"Total sales tax on an item that costs $"<<itemP<<" is $"<<totTAX<<endl;

    //Exit stage right!
    return 0;
}