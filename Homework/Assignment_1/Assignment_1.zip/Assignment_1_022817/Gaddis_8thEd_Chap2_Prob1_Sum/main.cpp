/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February, 2017, 3:15 PM
  Purpose: Programming challenge 1, sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned char numone=50;//integer 50
    unsigned char numtwo=100;//integer 100
    unsigned short total;// total variable
    
    //Input values
    
    //Process by mapping inputs to outputs
    total=numone+numtwo; //Sum
    
    //Output values
    cout<<"Sum of 100 and 50 = "<<total<<endl;

    //Exit stage right!
    return 0;
}