/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on February 25, 2017, 8:44 PM
  Purpose: Programming challenge 5, Average of Values
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short val1, val2, val3, val4, val5;//values for averaging
    val1=28;
    val2=32;
    val3=37;
    val4=24;
    val5=33;
    unsigned short sum;//sum of all the values
    float avg;//average of the values
    
    //Input values
    
    //Process by mapping inputs to outputs
    sum=val1+val2+val3+val4+val5;
    avg=sum/5.0;
    
    //Output values
    cout<<"The average of 24,28,32,33 and 37 is "<<avg<<endl;

    //Exit stage right!
    return 0;
}