/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Calculating Male and Female percentages
 */

//System Libraries
#include <iostream>
#include <iomanip>//formatting
using namespace std;

//User Libraries

//Global Constant
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short male;  //Number of males
    unsigned short female;//Number of females
    float pmale, pfemale; //percentages of males and females
    
    //Input values
    cout<<"This program will calculate the percentage of male and female students."<<endl;
    cout<<"Input the number of males: ";
    cin>>male;
    cout<<"Input the number of females: ";
    cin>>female;
    
    
    //Process by mapping inputs to outputs
    pmale=static_cast<float>(male)/(male+female)*100;
    pfemale=static_cast<float>(female)/(male+female)*100;
    
    //Output values
    cout<<setprecision(2);
    cout<<"The percentage of males in the class is "<<pmale<<"%."<<endl;
    cout<<"The percentage of females in the class is "<<pfemale<<"%."<<endl;

    //Exit stage right!
    return 0;
}