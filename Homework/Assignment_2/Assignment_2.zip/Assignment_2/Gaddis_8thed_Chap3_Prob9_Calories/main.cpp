/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Calories consumed
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constant
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short servC=3;    //Cookies per serving
    unsigned short servCal=300;//Calories per serving of cookies
    unsigned short cookie;     //User inputted number of cookies
    unsigned short numCal;     //Number calories consumed
    
    //Input values
    cout<<"This program will calculate the number of calories consumed."<<endl;
    cout<<"Input how many cookies you actually ate: ";
    cin>>cookie;
    
    //Process by mapping inputs to outputs
    numCal=cookie*(servCal/servC);
    
    //Output values
    cout<<"You consumed "<<numCal<<" calories."<<endl;

    //Exit stage right!
    return 0;
}