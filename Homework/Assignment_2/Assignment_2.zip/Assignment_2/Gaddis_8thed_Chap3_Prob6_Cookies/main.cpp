/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Baking Cookies
 */

//System Libraries
#include <iostream>
#include <iomanip>//formatting
using namespace std;

//User Libraries

//Global Constant
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short cookie;          //User submitted number of cookies
    float cSug=1.5,                 //1.5 cups of sugar
          cBut=1,                   //1 cup of butter
          cFlo=2.75;                //2.75 cups of flour   
    unsigned short bcookie=48;      //Batch of cookies is 48
    float numSug, numBut, numFlo;   //User requirements of sugar, butter and flour
    
    //Input values
    cout<<"This program will calculate the amount of ingredients to make cookies."<<endl;
    cout<<"Input the number of cookies you'd like to make: ";
    cin>>cookie;
    
    
    //Process by mapping inputs to outputs
    numSug=(cSug/bcookie)*cookie;
    numBut=(cBut/bcookie)*cookie;
    numFlo=(cFlo/bcookie)*cookie;
    
    //Output values
    cout<<setprecision(2);
    cout<<"You will need "<<numSug<<" cups of sugar, "<<numBut<<" cups of butter, and ";
    cout<<numFlo<<" cups of flour to make "<<cookie<<" cookies."<<endl;

    //Exit stage right!
    return 0;
}