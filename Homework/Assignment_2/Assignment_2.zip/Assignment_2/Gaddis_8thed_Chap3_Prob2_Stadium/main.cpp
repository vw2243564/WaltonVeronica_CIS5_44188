/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Ticket Sales
 */

//System Libraries
#include <iostream>
#include <iomanip>//Formating
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short aTick=15;//Class A Ticket cost in dollars
    unsigned short bTick=12;//Class B Ticket cost in dollars
    unsigned short cTick=9; //Class C Ticket cost in dollars
    float total;            //Total cost of all tickets sold
    
    //Input values
    cout<<"Input the amount of Class A tickets sold:"<<endl;
    cin>>aTick;
    cout<<"Input the amount of Class B tickets sold:"<<endl;
    cin>>bTick;
    cout<<"Input the amount of Class C tickets sold:"<<endl;
    cin>>cTick;
    
    //Process by mapping inputs to outputs
    total=aTick+bTick+cTick;
    
    //Output values
    cout<<setprecision(2)<<fixed;
    cout<<"Total income from ticket sales is $"<<total<<"."<<endl;

    //Exit stage right!
    return 0;
}