/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Test Average
 */

//System Libraries
#include <iostream>
#include <iomanip>//Formating
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short test1, test2, test3, test4, test5;//Test scores
    float testAvg;// Test Average
    
    //Input values
    cout<<"This program will calculate your average test scores."<<endl;
    cout<<"Input first test score: ";
    cin>>test1;
    cout<<"Input second test score: ";
    cin>>test2;
    cout<<"Input third test score: ";
    cin>>test3;
    cout<<"Input fourth test score: ";
    cin>>test4;
    cout<<"Input fifth test score: ";
    cin>>test5;
    
    //Process by mapping inputs to outputs
    testAvg=(test1+test2+test3+test4+test5)/5;
    
    //Output values
    cout<<setprecision(1)<<fixed;
    cout<<"Test average is "<<testAvg<<"%"<<endl;

    //Exit stage right!
    return 0;
}