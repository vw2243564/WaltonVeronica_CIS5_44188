/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Average Rainfall
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char mnth1[10], mnth2[10], mnth3[10];//User input of months
    unsigned short rain1, rain2, rain3;//Amount of rainfall in each month in inches
    unsigned short rainAvg;            //Average rainfall
    
    //Input values
    cout<<"This program will calculate the average rainfall for three months."<<endl;
    cout<<"Input the name of the first month and how many inches of rain fell :";
    cin>>mnth1;
    cin>>rain1;
    cout<<"Input the name of the second month and how many inches of rain fell :";
    cin>>mnth2;
    cin>>rain2;
    cout<<"Input the name of the third month and how many inches of rain fell :";
    cin>>mnth3;
    cin>>rain3;
    
    //Process by mapping inputs to outputs
    rainAvg=(rain1+rain2+rain3)/3;
    
    //Output values
    cout<<"The rainfall average for "<<mnth1<<", "<<mnth2<<", and "<<mnth3<<" is "<<rainAvg<<" inches."endl;

    //Exit stage right!
    return 0;
}