/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Calculate insurance bought
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constant
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float repC;    //User inputted replacement cost of building in dollars
    float ins=0.80;//Percent of insurance
    float tot;     //Total amount of insurance in dollars
    
    //Input values
    cout<<"This program will calculate the minimum amount of insurance to purchase."<<endl;
    cout<<"Input the replacement cost of building: $";
    cin>>repC;
    
    //Process by mapping inputs to outputs
    tot=repC*ins;
    
    //Output values
    cout<<"You should purchase $"<<tot<<" worth of insurance."<<endl;

    //Exit stage right!
    return 0;
}