/* 
 * File:   main.cpp
 * Author: Veronica Walton
 * Created on March 5, 2017, 11:59 AM
 * Purpose:  Calculate a car's gas mileage
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    unsigned short numGal;//User inputs number of gallons car can hold
    int numMile;          //User inputs number of miles car can go on full tank of gas
    float galMile;         //Number of miles per gallon of gas
    
    
    //Initialize variables
    
    //Input data
    cout<<"This program calculates your car's miles per gallon of gas."<<endl;
    cout<<"Input the number of gallons your car holds here:"<<endl;
    cin>>numGal;
    cout<<"Input the number of miles your car can go on a full tank of gas:"<<endl;
    cin>>numMile;
    
    galMile= static_cast<float>(numMile)/(float)(numGal);
    //Map inputs to outputs or process the data
    
    //Output the transformed data
    cout<<"The number of miles per gallon of gas your car gets is:"<<galMile<<"."<<endl;
    
    //Exit stage right!
    return 0;
}

