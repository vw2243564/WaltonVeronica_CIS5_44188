/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Calculate widgets
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constant
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    unsigned short wtPall; //User input of weight of pallet in pounds
    unsigned short totPall;//User input of total weight of pallet and widgets in pounds
    float wid=12.5;        //widgets weight 12.5 pounds each
    unsigned short numWid; //Number of widgets
    
    //Input values
    cout<<"This program will calculate number of widgets on a pallet."<<endl;
    cout<<"Input weight of the pallet in pounds: "<<endl;
    cin>>wtPall;
    cout<<"Input total weight of pallet with widgets: "<<endl;
    cin>>totPall;
    
    //Process by mapping inputs to outputs
    numWid=(totPall-wtPall)/wid;
    
    //Output values
    cout<<"There are "<<numWid<<" widgets on the pallet."<<endl;

    //Exit stage right!
    return 0;
}