/* 
  File:   main.cpp
  Author: Veronica Walton
  Created on March 9, 2017, 10:00 PM
  Purpose:  Calculate profits for a night
 */

//System Libraries
#include <iostream>
#include <iomanip>//formatting
using namespace std;

//User Libraries

//Global Constant
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char mName[30];//Name of movie
    unsigned short aTick, cTick;     //User inputted adult and child tickets
    unsigned short aCost=10, cCost=6;//Cost of adult and child tickets
    unsigned short gBox;             //Gross Box Office Profit
    float netBox, dist;              //Net Box Profit and Amount paid to distributor
    
    //Input values
    cout<<"This program will calculate revenue."<<endl;
    cout<<"Input the name of the movie: ";
    cin>>mName;
    cout<<"Input how many adult tickets were sold: ";
    cin>>aTick;
    cout<<"Input how many child tickets were sold: ";
    cin>>cTick;
    
    //Process by mapping inputs to outputs
    gBox=(aTick*aCost)+(cTick+cCost);
    netBox=gBox*.20;
    dist=gBox-netBox;
    
    //Output values
    cout<<left<<setw(30)<<"Movie Name: "<<right<<setw(20)<<mName<<right<<endl;
    cout<<left<<setw(30)<<"Adult Tickets sold: "<<right<<setw(20)<<aTick<<endl;
    cout<<left<<setw(30)<<"Child Tickets sold: "<<right<<setw(20)<<cTick<<endl;
    cout<<setprecision(2)<<fixed;
    cout<<left<<setw(30)<<"Gross Box Office Profit: "<<right<<setw(20)<<gBox<<endl;
    cout<<left<<setw(30)<<"Net Box Office Profit: "<<right<<setw(20)<<netBox<<endl;
    cout<<left<<setw(30)<<"Amount paid to Distributor: "<<right<<setw(20)<<dist<<endl;

    //Exit stage right!
    return 0;
}